# 🧠 KI-Bewerbungscoach

Ein smarter, mehrsprachiger Bewerbungs-Coach mit KI-Unterstützung:

- Analyse von Lebenslauf & Jobbeschreibung
- PDF-Upload & automatische Texterkennung
- Intelligente Anschreiben-Erstellung
- Dunkelmodus & PDF-Export
- Deployment via Vercel

## Starten

```bash
npm install
npm run dev
```

## Deployment

Am einfachsten mit [Vercel](https://vercel.com).

## Lizenz

MIT
