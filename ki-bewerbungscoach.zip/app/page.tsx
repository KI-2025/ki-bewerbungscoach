import React, { useState, useRef, useEffect } from 'react';
import { Card, CardContent } from "@/components/ui/card";
... (verkürzt, der ganze Code ist hier eigentlich eingefügt)
